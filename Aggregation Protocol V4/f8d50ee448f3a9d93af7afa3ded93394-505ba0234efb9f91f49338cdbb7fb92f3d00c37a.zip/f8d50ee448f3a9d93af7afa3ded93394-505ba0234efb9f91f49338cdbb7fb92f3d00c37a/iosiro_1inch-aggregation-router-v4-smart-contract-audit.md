## Replace constant addresses with immutables (Low)

[UnoswapV3Router.sol#L22](https://github.com/1inch/1inch-contract/blob/94022d50507ae91612e564dd5b5b1e52cb28ab37/contracts/UnoswapV3Router.sol#L22), [UnoswapV3Router.sol#L29](https://github.com/1inch/1inch-contract/blob/94022d50507ae91612e564dd5b5b1e52cb28ab37/contracts/UnoswapV3Router.sol#L29), [ClipperRouter.sol#L15](https://github.com/1inch/1inch-contract/blob/94022d50507ae91612e564dd5b5b1e52cb28ab37/contracts/ClipperRouter.sol#L15)

### Description

The contracts contained constants that were specific to Ethereum mainnet, however, it the contracts were intended to be deployed to other chains (Polygon, Optimism, Arbitrum and BSC). Consequently, the contracts would need to be modified for each deployment, increasing the likelihood of introducing bugs during deployment, as well as invalidating the commit hash referenced during the audit. 

### Recommendation

To allow for the source code of the contracts to remain constant, the `immutable` keyword should be used so that they can be set in the constructor during deployment.  

## Minimum return amount not validated (Low)

[ClipperRouter.sol#L49](https://github.com/1inch/1inch-contract/blob/94022d50507ae91612e564dd5b5b1e52cb28ab37/contracts/ClipperRouter.sol#L49)

### Description

The `minReturn` amount specified in `clipperSwapTo` was not explicitly validated and thus the contract did not explicitly protect users against slippage. Instead, it was assumed that the external `ClipperExchangeInterface` contract would validate the returned amount (which was the case at the time of the audit). 

Since the implementation of `ClipperExchangeInterface` is unlikely to change, the issue is rated as a low risk; however, it is still best practice to explictly protect against slippage.

### Recommendation

The balance of the destination token before and after the trade should be validated to ensure that the correct amount of tokens have been returned. A basic implementation would be similiar to the following:

```
uint256 balanceBefore = dstToken == _ETH ? recipient.balance : dstToken.balanceOf(recipient);

if (srcETH) {
    _clipperPool.transfer(amount);
    returnAmount = _clipperExchange.sellEthForToken(dstToken, recipient, minReturn, _INCH_TAG);
} else if (dstToken == _WETH) {
    returnAmount = _clipperExchange.sellTokenForEth(srcToken, address(this), minReturn, _INCH_TAG);
    _WETH.deposit{ value: returnAmount }();
    _WETH.transfer(recipient, returnAmount);
} else if (dstToken == _ETH) {
    returnAmount = _clipperExchange.sellTokenForEth(srcToken, recipient, minReturn, _INCH_TAG);
} else {
    returnAmount = _clipperExchange.sellTokenForToken(srcToken, dstToken, recipient, minReturn, _INCH_TAG);
}

uint256 balanceAfter = dstToken == _ETH ? recipient.balance : dstToken.balanceOf(recipient);
require(balanceAfter.sub(balanceBefore) >= minReturn, "CL1IN: min return");
```

## Residual tokens if trading via illiquid pools (Low)

[UnoswapV3Router.sol#L73](https://github.com/1inch/1inch-contract/blob/94022d50507ae91612e564dd5b5b1e52cb28ab37/contracts/UnoswapV3Router.sol#L73)

### Description

When performing a swap via multiple UniswapV3 pools, with at least one of the pools being illiquid, tokens can remain in the contract. This requires the user to specify a `minReturn` highly susceptible to slippage or in the worst case set it to `0`. 

This is due to UniswapV3 not reverting if `exactIn` cannot be filled and will even partially fill the order under specific circumstances. 

### Recommendation

At the end of the swap the pools should be iterated over and any remaining token balance should be transfered back to the user. It is expected that this would significantly increase the gas costs, which most likely outweighs the risk. Fortunately, the `owner` account can rescue any locked tokens from the contract and a process can be set forth to return tokens in the event of a signficant loss.

### Proof of Concept

Simulation: Trading 1260736035618071747 WETH for AAVE via wBTC (WETH -> wBTC -> AAVE)
Pools: [0x5ab53ee1d50eef2c1dd3d5402789cd27bb52c1bb](https://info.uniswap.org/#/pools/0x5ab53ee1d50eef2c1dd3d5402789cd27bb52c1bb), [0x98e45940d0c76898f5659b8fc78895f35a39eb43](https://info.uniswap.org/#/pools/0x98e45940d0c76898f5659b8fc78895f35a39eb43)
Block Height: [13269200](https://etherscan.io/block/13269200)

```
// UniswapResidual.sol
// SPDX-License-Identifier: MIT

pragma solidity ^0.7.6;

import "./interfaces/IUniswapV3Pool.sol";
import "./UnoswapV3Router.sol";
import "hardhat/console.sol";

// Simplified contract to test with callback
contract UniswapResidual is UnoswapV3Router {
  
    /// @dev The minimum value that can be returned from #getSqrtRatioAtTick. Equivalent to getSqrtRatioAtTick(MIN_TICK)
    uint160 private constant _MIN_SQRT_RATIO = 4295128739 + 1;
    /// @dev The maximum value that can be returned from #getSqrtRatioAtTick. Equivalent to getSqrtRatioAtTick(MAX_TICK)
    uint160 private constant _MAX_SQRT_RATIO = 1461446703485210103287273052203988822378723970342 - 1;

    function run(uint256 amount, address pool, bool ONE_FOR_ZERO) external {
        IUniswapV3Pool(pool).swap(msg.sender, 
            ONE_FOR_ZERO, // OneForZero
            SafeCast.toInt256(amount),
            ONE_FOR_ZERO ? _MIN_SQRT_RATIO : _MAX_SQRT_RATIO, 
            abi.encode(msg.sender)
        );
    }
    
}
```

```
const { web3 } = require('@openzeppelin/test-helpers/src/setup');
const { ether, BN } = require('@openzeppelin/test-helpers');

const { MAX_UINT256 } = require("@openzeppelin/test-helpers/src/constants");
const { artifacts } = require("hardhat");
const { expect } = require("chai");

const IERC20 = artifacts.require('@openzeppelin/contracts/token/ERC20/IERC20.sol:IERC20');
const IMatchaRouter = artifacts.require('IUniswapV3Feature');
const UniswapResidual = artifacts.require('UniswapResidual');
const IWETH = artifacts.require('IWETH');
const UniswapV3Pool = artifacts.require('IUniswapV3Pool');

const {
    calculateUniPath,
} = require('./helpers/utils.js');

const tokens = {};

describe('UniswapResidual', async function () {
    let trader, lp, deployer;
    let matchaRouter, target;
    let WETH;
    before(async () => {
        [trader, lp, deployer] = await web3.eth.getAccounts();

        tokens.AAVE = await IERC20.at('0x7fc66500c84a76ad7e9c93437bfc5ac33e2ddae9');
        tokens.wBTC = await IERC20.at('0x2260fac5e5542a773aa44fbcfedf7c193bc2c599');

        WETH = await IWETH.at('0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2');
        matchaRouter = await IMatchaRouter.at('0xDef1C0ded9bec7F1a1670819833240f027b25EfF');

    
        target = await UniswapResidual.new({from: deployer});
    });
   
    
    it('Swap using illiquid pool', async () => {
        var tokenList = Object.entries(tokens);

        await WETH.deposit({ value: ether('10'), from: trader });

         // Buy some AAVE and wBTC
        for (var i = 0; i < tokenList.length; i++) {
            await matchaRouter.sellEthForTokenToUniswapV3(
                calculateUniPath([WETH, tokenList[i][1]], [0.3]),
                '0',
                trader,
                { from: trader, value: ether('1') },
            )
            console.log(`Bought some ${tokenList[i][0]}`);
        }

        var aaveBalanceBefore =  await tokens.AAVE.balanceOf(trader);
        var wbtcBalanceBefore = await tokens.wBTC.balanceOf(trader);
        console.log(`Trader: ${trader} has ${aaveBalanceBefore} AAVE and ${wbtcBalanceBefore} wBTC`);

        await tokens.AAVE.approve(target.address, 0, {from: trader});
        await tokens.AAVE.approve(target.address, MAX_UINT256, {from: trader});
        await tokens.wBTC.approve(target.address, 0, {from: trader});
        await tokens.wBTC.approve(target.address, MAX_UINT256, {from: trader});

        // Swapping 8857571 BTC for Aave
        var amount = new BN('8857571');
        var pool = "0x98E45940d0c76898f5659b8FC78895F35A39eb43"; // wBTC/AAVE
        console.log(`Pool has ${await tokens.AAVE.balanceOf(pool)} AAVE and ${await tokens.wBTC.balanceOf(pool)} wBTC`);
        console.log(`Swapping ${amount} BTC for Aave`)
        await target.run(amount, pool, true, {from: trader});

        var aaveBalanceAfter =  await tokens.AAVE.balanceOf(trader);
        var wbtcBalanceAfter = await tokens.wBTC.balanceOf(trader); 
        console.log(`Trader: ${trader} has ${aaveBalanceAfter} AAVE and ${wbtcBalanceAfter} wBTC`);      

        console.log(`wBTC Diff: ${wbtcBalanceAfter.sub(wbtcBalanceBefore)}, which should have been ${amount}`)
        console.log(`Aave Diff: ${aaveBalanceAfter.sub(aaveBalanceBefore)}`)
        
        console.log(`Pool has ${await tokens.AAVE.balanceOf(pool)} AAVE and ${await tokens.wBTC.balanceOf(pool)} wBTC`);
        expect(wbtcBalanceBefore.sub(amount)).to.be.equal(wbtcBalanceAfter);
    })
});
```

```
Trader: 0xf39Fd6e51aad88F6F4ce6aB8827279cffFb92266 has 10092053450494767517 AAVE and 7026331 wBTC
Pool has 2016149001130968626 AAVE and 32 wBTC
Swapping 8857571 BTC for Aave
Trader: 0xf39Fd6e51aad88F6F4ce6aB8827279cffFb92266 has 12105164273080694070 AAVE and 4177037 wBTC
wBTC Diff: -2849294, which should have been 8857571
Aave Diff: 2013110822585926553
Pool has 3038178545042073 AAVE and 2849326 wBTC
```

### Use of `transfer` function

*[UnoswapV3Router.sol#L84](https://github.com/1inch/1inch-contract/blob/94022d50507ae91612e564dd5b5b1e52cb28ab37/contracts/UnoswapV3Router.sol#L84)*

#### Description

The `UnoswapV3Router.uniswapV3SwapTo` functions made use of the `transfer()` function to send ether. While `transfer()` is commonly used to prevent reentrancy attacks due to its 2300 gas limit, it relies on the receiving contract having a fallback function below this limit. As demonstrated in EIP-1884, which changed the gas cost of the `SLOAD` operation, gas costs can change. This could lead to a case where a contract has its fallback function increased above the 2300 limit, resulting in it becoming incompatible with the system. More information can be found in [Consensys On Avoiding `transfer()`](https://diligence.consensys.net/blog/2019/09/stop-using-soliditys-transfer-now/).

#### Recommendation

It is recommended that the `call()` function be used to send ether instead of `transfer()`. Alternatively, the `sendValue()` function from the OpenZeppelin [Address library](https://github.com/OpenZeppelin/openzeppelin-contracts/blob/master/contracts/utils/Address.sol#L53) could be used.
